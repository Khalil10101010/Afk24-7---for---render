### بوت AFK
<p align="center"> 
    <img src="https://img.shields.io/github/issues/urfate/afk-bot">
    <img src="https://img.shields.io/github/forks/urfate/afk-bot">
    <img src="https://img.shields.io/github/stars/urfate/afk-bot">
    <img src="https://img.shields.io/github/license/urfate/afk-bot">
</p>

<p align="center">
    بوت AFK عملي لماينكرافت لخوادم اللعب
</p>

<p align="center">
    مكافحة AFK، تسجيل تلقائي، دعم حسابات Microsoft/Offline.
</p>

## الشرح

1. شاهد هذا الفيديو السريع لمدة 3 دقائق [هنا](https://youtu.be/g6OScmu3O5g) وادعم القناة بالاشتراك.
2. قم بعمل Fork للكود بالضغط على الزر أعلى اليمين.
3. قم بالإعجاب بالكود حتى أتمكن من تحديثه باستمرار!

## التثبيت

 1. [تحميل](https://github.com/urFate/Afk-Bot/tags) أحدث إصدار.
 2. قم بتنزيل وتثبيت [Node.JS](https://nodejs.org/en/download/)
 3. نفّذ الأمر `npm install` داخل مجلد البوت.
 
 ## الاستخدام
 
 1. قم بإعداد البوت في ملف `settings.json`. [شرح إعداد البوت موجود في ويكي المشروع](https://urfate.gitbook.io/afk-bot/bot-configuration)
 2. شغّل البوت باستخدام الأمر `node .`.

## الميزات

 - وحدة مكافحة الطرد بسبب الـ AFK
 - التحرك إلى الكتلة المستهدفة بعد تسجيل الدخول
 - دعم حسابات Mojang/Microsoft
 - سجل المحادثات
 - وحدة رسائل المحادثة
 - إعادة الاتصال التلقائي
 - المصادقة مع Login Security [هنا](https://aternos.org/addons/a/spigot/19362) (إضافة مصادقة للخوادم غير الرسمية)
 - إصدارات الخوادم المدعومة: `1.8 - 1.21.3`
 
آمل أن يكون هذا مفيدًا لك! أخبرني إذا كنت بحاجة إلى أي مساعدة إضافية. 🚀